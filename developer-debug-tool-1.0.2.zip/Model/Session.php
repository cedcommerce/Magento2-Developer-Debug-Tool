<?php
/**
 * Copyright © 2015 Cedcommerce. All rights reserved.
 */
namespace Ced\DevTool\Model;

/**
 * DevTool session model
 */
class Session extends \Magento\Framework\Session\SessionManager
{
}
